python3 ASTARBusQ.py ASTAR-tests/easytest.prob 1
python3 ASTARBusQ.py ASTAR-tests/easytest.prob 2
python3 ASTARBusQ.py ASTAR-tests/students.prob 1
python3 ASTARBusQ.py ASTAR-tests/students.prob 2
python3 ASTARBusQ.py ASTAR-tests/test3.prob 1
python3 ASTARBusQ.py ASTAR-tests/test3.prob 2
python3 ASTARBusQ.py ASTAR-tests/test4.prob 1
python3 ASTARBusQ.py ASTAR-tests/test4.prob 2